import {
  SlashCommandBuilder, ChatInputCommandInteraction,
  ChannelType, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder
} from "discord.js";
import { db, ticketsTable } from "@workspace/db";
import { getOrCreateUser } from "../utils/db";
import { baseEmbed, errorEmbed, formatRobux, BOT_COLOR, LOSE_COLOR } from "../utils/embed";

export const data = new SlashCommandBuilder()
  .setName("withdraw")
  .setDescription("Request a Robux withdrawal — creates a private ticket for admin approval")
  .addIntegerOption(opt =>
    opt.setName("amount").setDescription("Amount of Robux to withdraw").setRequired(true).setMinValue(1)
  );

export async function execute(interaction: ChatInputCommandInteraction) {
  if (!interaction.guild) {
    await interaction.reply({ embeds: [errorEmbed("This command can only be used in a server.")], ephemeral: true });
    return;
  }
  const amount = interaction.options.getInteger("amount", true);
  const user = await getOrCreateUser(interaction.user.id, interaction.user.username);
  if (user.balance < amount) {
    await interaction.reply({ embeds: [errorEmbed(`You only have ${formatRobux(user.balance)} — can't withdraw ${formatRobux(amount)}.`)], ephemeral: true });
    return;
  }

  const channel = await interaction.guild.channels.create({
    name: `withdraw-${interaction.user.username}`.toLowerCase().replace(/[^a-z0-9-]/g, "-").replace(/^-+|-+$/g, "").slice(0, 100),
    type: ChannelType.GuildText,
    permissionOverwrites: [
      { id: interaction.guild.roles.everyone, deny: [PermissionFlagsBits.ViewChannel] },
      { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
      { id: interaction.client.user!.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.ReadMessageHistory] },
    ],
  });

  const [ticket] = await db.insert(ticketsTable).values({
    channelId: channel.id,
    userId: interaction.user.id,
    username: interaction.user.username,
    type: "withdraw",
    amount,
    status: "pending",
  }).returning();

  const embed = new EmbedBuilder()
    .setTitle("💸 Withdrawal Request")
    .setColor(LOSE_COLOR)
    .setThumbnail(interaction.user.displayAvatarURL())
    .addFields(
      { name: "User", value: `<@${interaction.user.id}>`, inline: true },
      { name: "Amount", value: formatRobux(amount), inline: true },
      { name: "Current Balance", value: formatRobux(user.balance), inline: true },
      { name: "Balance After", value: formatRobux(user.balance - amount), inline: true },
      { name: "Status", value: "⏳ Pending", inline: true },
    )
    .setFooter({ text: `Ticket #${ticket.id} • Channel deletes automatically on approval/denial` })
    .setTimestamp();

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(`ticket_approve_${ticket.id}`).setLabel("✅ Approve").setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId(`ticket_deny_${ticket.id}`).setLabel("❌ Deny").setStyle(ButtonStyle.Danger),
  );

  await channel.send({ content: `<@${interaction.user.id}> Your withdrawal ticket is open. An admin will review it shortly.`, embeds: [embed], components: [row] });
  await interaction.reply({
    embeds: [baseEmbed("🎫 Ticket Created!").setDescription(`Withdrawal request for ${formatRobux(amount)} submitted.\n\nHead to ${channel} to track it.`)],
    ephemeral: true,
  });
}
